﻿namespace AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.panelheader = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelbar = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttondashboard = new System.Windows.Forms.Button();
            this.buttonappointment = new System.Windows.Forms.Button();
            this.buttoncalendaar = new System.Windows.Forms.Button();
            this.buttonsched = new System.Windows.Forms.Button();
            this.mainpanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panelheader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelbar.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panelheader
            // 
            this.panelheader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(215)))), ((int)(((byte)(0)))));
            this.panelheader.Controls.Add(this.label2);
            this.panelheader.Controls.Add(this.label1);
            this.panelheader.Controls.Add(this.pictureBox1);
            this.panelheader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelheader.Location = new System.Drawing.Point(0, 0);
            this.panelheader.Name = "panelheader";
            this.panelheader.Size = new System.Drawing.Size(984, 44);
            this.panelheader.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Yellow;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.label2.Location = new System.Drawing.Point(953, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "X";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(290, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "REGISTRAR MANAGEMENT SYSTEM";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 38);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panelbar
            // 
            this.panelbar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(1)))), ((int)(((byte)(111)))));
            this.panelbar.Controls.Add(this.panel2);
            this.panelbar.Controls.Add(this.panel3);
            this.panelbar.Controls.Add(this.pictureBox2);
            this.panelbar.Controls.Add(this.button1);
            this.panelbar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelbar.Location = new System.Drawing.Point(0, 44);
            this.panelbar.Name = "panelbar";
            this.panelbar.Size = new System.Drawing.Size(275, 614);
            this.panelbar.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(272, 168);
            this.panel2.TabIndex = 0;
            // 
            // buttondashboard
            // 
            this.buttondashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(1)))), ((int)(((byte)(111)))));
            this.buttondashboard.FlatAppearance.BorderSize = 0;
            this.buttondashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttondashboard.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.buttondashboard.ForeColor = System.Drawing.Color.White;
            this.buttondashboard.Image = ((System.Drawing.Image)(resources.GetObject("buttondashboard.Image")));
            this.buttondashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttondashboard.Location = new System.Drawing.Point(-3, -10);
            this.buttondashboard.Name = "buttondashboard";
            this.buttondashboard.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.buttondashboard.Size = new System.Drawing.Size(279, 45);
            this.buttondashboard.TabIndex = 0;
            this.buttondashboard.Text = "DASHBOARD";
            this.buttondashboard.UseVisualStyleBackColor = false;
            this.buttondashboard.Click += new System.EventHandler(this.buttondashboard_Click);
            // 
            // buttonappointment
            // 
            this.buttonappointment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(1)))), ((int)(((byte)(111)))));
            this.buttonappointment.FlatAppearance.BorderSize = 0;
            this.buttonappointment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonappointment.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.buttonappointment.ForeColor = System.Drawing.Color.White;
            this.buttonappointment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonappointment.Location = new System.Drawing.Point(-7, 32);
            this.buttonappointment.Name = "buttonappointment";
            this.buttonappointment.Size = new System.Drawing.Size(279, 45);
            this.buttonappointment.TabIndex = 1;
            this.buttonappointment.Text = "APPOINTMENT";
            this.buttonappointment.UseVisualStyleBackColor = false;
            this.buttonappointment.Click += new System.EventHandler(this.buttonappointment_Click);
            // 
            // buttoncalendaar
            // 
            this.buttoncalendaar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(1)))), ((int)(((byte)(111)))));
            this.buttoncalendaar.FlatAppearance.BorderSize = 0;
            this.buttoncalendaar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttoncalendaar.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.buttoncalendaar.ForeColor = System.Drawing.Color.White;
            this.buttoncalendaar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttoncalendaar.Location = new System.Drawing.Point(-3, 112);
            this.buttoncalendaar.Name = "buttoncalendaar";
            this.buttoncalendaar.Size = new System.Drawing.Size(279, 45);
            this.buttoncalendaar.TabIndex = 3;
            this.buttoncalendaar.Text = "SCHOOL CALENDAR";
            this.buttoncalendaar.UseVisualStyleBackColor = false;
            this.buttoncalendaar.Click += new System.EventHandler(this.buttoncalendaar_Click);
            // 
            // buttonsched
            // 
            this.buttonsched.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(1)))), ((int)(((byte)(111)))));
            this.buttonsched.FlatAppearance.BorderSize = 0;
            this.buttonsched.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonsched.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.buttonsched.ForeColor = System.Drawing.Color.White;
            this.buttonsched.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonsched.Location = new System.Drawing.Point(0, 72);
            this.buttonsched.Name = "buttonsched";
            this.buttonsched.Size = new System.Drawing.Size(279, 45);
            this.buttonsched.TabIndex = 2;
            this.buttonsched.Text = "REGISTRAR SCHEDULE";
            this.buttonsched.UseVisualStyleBackColor = false;
            this.buttonsched.Click += new System.EventHandler(this.buttonsched_Click);
            // 
            // mainpanel
            // 
            this.mainpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainpanel.Location = new System.Drawing.Point(275, 44);
            this.mainpanel.Name = "mainpanel";
            this.mainpanel.Size = new System.Drawing.Size(709, 614);
            this.mainpanel.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.Yellow;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial Black", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Navy;
            this.button1.Location = new System.Drawing.Point(3, 564);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(279, 37);
            this.button1.TabIndex = 0;
            this.button1.Text = "LOGOUT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel3.Controls.Add(this.buttonsched);
            this.panel3.Controls.Add(this.buttondashboard);
            this.panel3.Controls.Add(this.buttoncalendaar);
            this.panel3.Controls.Add(this.buttonappointment);
            this.panel3.Location = new System.Drawing.Point(3, 177);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(279, 157);
            this.panel3.TabIndex = 2;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(3, 340);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 218);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(984, 658);
            this.Controls.Add(this.mainpanel);
            this.Controls.Add(this.panelbar);
            this.Controls.Add(this.panelheader);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.panelheader.ResumeLayout(false);
            this.panelheader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelbar.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelheader;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.FlowLayoutPanel panelbar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel mainpanel;
        private System.Windows.Forms.Button buttondashboard;
        private System.Windows.Forms.Button buttoncalendaar;
        private System.Windows.Forms.Button buttonsched;
        private System.Windows.Forms.Button buttonappointment;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}