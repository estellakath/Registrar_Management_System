﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
{
    public partial class Sidebar_calendar : Form
    {
        public Sidebar_calendar()
        {
            InitializeComponent();
        }
    }
}
